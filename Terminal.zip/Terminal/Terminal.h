#ifndef TERMINAL_H
#define TERMINAL_H

#include "SRF05Conf.h"


class Terminal {
public:
    Terminal();

    DistanceUnit askUnit(unsigned long timeout = 5000);
    float askVelocityOfSound(unsigned long timeout = 5000);
    float askThreshold(unsigned long timeout = 5000);

private:
    String readLine(unsigned long timeout);
    void prompt(const String& message);
};

#endif