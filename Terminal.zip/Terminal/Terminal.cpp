#include "Terminal.h"

Terminal::Terminal() {}

String Terminal::readLine(unsigned long timeout) {
    String input = "";
	char c = NULL;
    unsigned long start = millis();
    while ((millis() - start) < timeout) {
        while (Serial.available()) {
            c = Serial.read();
           if (c == '\n' || c == '\r') {
                break;
            }
			input += c;

        }
		if (c == '\n' || c == '\r') {
            break;
        }
    }
    return input;
}

void Terminal::prompt(const String& message) {
    Serial.println(message);
    Serial.print("> ");
}

DistanceUnit Terminal::askUnit(unsigned long timeout) {
    prompt("Select unit: (1) CM or (2) INCH");
    String input = readLine(timeout);
    if (input == "2") return INCH;
    return CM;
}

float Terminal::askVelocityOfSound(unsigned long timeout) {
    prompt("Enter velocity of sound in m/s (e.g. 343):");
    String input = readLine(timeout);
    return input.toFloat();
}

float Terminal::askThreshold(unsigned long timeout) {
    prompt("Enter threshold distance:");
    String input = readLine(timeout);
    return input.toFloat();
}