#include "SRF05Conf.h"

SRF05Conf::SRF05Conf(uint8_t trigPin, uint8_t echoPin, DistanceUnit unit) {
    _trigPin = trigPin;
    _echoPin = echoPin;
    _unit = unit;
    _velocityOfSound = 343.0; // default in m/s
	_threshold = 30.0; 

    pinMode(_trigPin, OUTPUT);
    pinMode(_echoPin, INPUT);
}

void SRF05Conf::setUnit(DistanceUnit unit) {
    _unit = unit;
}

DistanceUnit SRF05Conf::getUnit() {
    return _unit;
}

const char* SRF05Conf::getUnitString() {
    return (_unit == CM) ? "cm" : "inch";
}

void SRF05Conf::setPins(uint8_t trig, uint8_t echo) {
    _trigPin = trig;
    _echoPin = echo;
    pinMode(_trigPin, OUTPUT);
    pinMode(_echoPin, INPUT);
}

void SRF05Conf::setVelocityOfSound(float velocity) {
    _velocityOfSound = velocity;
}
void SRF05Conf::setThreshold(float threshold){
    _threshold = threshold;
}

float SRF05Conf::readDistance() {
    digitalWrite(_trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(_trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(_trigPin, LOW);

    long duration = pulseIn(_echoPin, HIGH);
    float distance_cm = (duration / 1e6) * (_velocityOfSound * 100.0) / 2.0;

    return (_unit == INCH) ? (distance_cm / 2.54) : distance_cm;
}

bool  SRF05Conf::detector(float threshold) {

        delay(10); // reduce stress on sensor
    return (readDistance()<=threshold);
}
bool  SRF05Conf::detector() {
        delay(10); // reduce stress on sensor
    return (readDistance()<= _threshold);
}

float SRF05Conf::readOptDistance() {
    unsigned long start = millis();
    float sum = 0;
    uint16_t count = 0;

    while (millis() - start < 100) {
        sum += readDistance();
        count++;
        delay(10); // reduce stress on sensor
    }

    float avg = sum / count;
    return avg ;
}
