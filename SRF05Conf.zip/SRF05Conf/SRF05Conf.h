#ifndef SRF05CONF_H
#define SRF05CONF_H

#include <Arduino.h>

enum DistanceUnit { CM, INCH };

class SRF05Conf {
public:
    SRF05Conf(uint8_t trigPin, uint8_t echoPin, DistanceUnit unit = CM);

    void setUnit(DistanceUnit unit);
    void setPins(uint8_t trig, uint8_t echo);
    void setVelocityOfSound(float velocity); // in m/s
    void setThreshold(float threshold);

    DistanceUnit getUnit();
    const char* getUnitString();

    float readDistance();
    bool detector(float threshold);
    bool detector();
    float readOptDistance(); 

private:
    uint8_t _trigPin, _echoPin;
    DistanceUnit _unit;
    float _velocityOfSound;  // in m/s
    float _threshold;
};

#endif
